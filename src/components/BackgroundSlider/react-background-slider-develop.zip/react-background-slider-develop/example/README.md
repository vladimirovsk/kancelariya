# React Background Slider Demo

Demo of the [React Background Slider](https://github.com/u2ix/react-background-slider)

## Image Credits

Photos on Unsplash by [Molly Martinez](https://unsplash.com/photos/88MqyyeY7Vw),
[Jordan Whitt](https://unsplash.com/photos/keSFbPQAJRE),
[Ethan Robertson](https://unsplash.com/photos/CcETP4gFBTU),
[Amber Teasley](https://unsplash.com/photos/u0cSubf5F-E),
[Heejing KIM](https://unsplash.com/photos/TqaFGqxiCQo)
and [Rich Dahlgren](https://unsplash.com/photos/3OvE-4rgpTc)
